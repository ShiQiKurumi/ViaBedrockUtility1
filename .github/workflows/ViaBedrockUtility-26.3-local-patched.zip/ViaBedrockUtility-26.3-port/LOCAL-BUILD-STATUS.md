# ViaBedrockUtility — Minecraft 26.3 local build status

Target: Minecraft 26.3 / Fabric Loader 0.19.5 / Java 25

## Local fixes applied in this iteration

- Replaced the remaining `Identifier.of(...)` calls in custom entity texture/entity-definition parsing with explicit namespace/path parsing through `Identifier.fromNamespaceAndPath(...)`.
- Added the missing `EntityRendererProvider` import used by `CustomEntityTicker`.
- Changed payload dispatch so Bedrock skin/cape packets are processed even when the server resource-pack `PackManager` is not initialized yet; model-request payloads still wait for it.
- Hardened `EntityRendererProvider.Context` creation for the 26.3 constructor shape by supplying available client resources reflectively and resolving the renderer's `EquipmentAssetManager` when present.
- Updated Lombok from 1.18.36 to 1.18.48 and moved it from the bundled `lib` configuration to `compileOnly` + `annotationProcessor`; Lombok 1.18.40 added JDK 25 support and 1.18.48 is the current release.
- Updated the Gradle wrapper distribution URL from 9.6 to 9.6.1.
- Updated both GitHub workflows to use Java 25 and upload the resulting mod JAR.
- Retained the earlier 26.3 changes to `ModelPart.getAllParts()` (now treated as `List<ModelPart>`) and the 26.3 player/entity render-state pipeline.

## Verification performed here

- All JSON resources parsed successfully.
- Workflow YAML parsed successfully when PyYAML was available.
- Text files were checked for NUL bytes and trailing whitespace.
- The local Gradle wrapper was invoked in offline mode. It cannot start because the Gradle 9.6.1 distribution is not installed in the sandbox.
- The sandbox has only OpenJDK 21.0.11. The project requires Java 25.
- The sandbox has no cached Minecraft/Fabric 26.3 dependency set and cannot reach the external Gradle/Maven endpoints needed for a real Loom compile.

## Important result

This directory is a patched **source/build project**, not a verified compiled JAR. No claim of a successful Java 25 + Minecraft 26.3 build is made until Gradle/Loom can actually execute with the required dependencies.

Expected JAR after a genuine build:

`build/libs/viabedrockutility-1.0.0-26.3.jar`
