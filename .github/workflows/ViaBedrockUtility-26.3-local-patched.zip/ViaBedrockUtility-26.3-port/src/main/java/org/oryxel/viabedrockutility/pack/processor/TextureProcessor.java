package org.oryxel.viabedrockutility.pack.processor;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.oryxel.viabedrockutility.fabric.ViaBedrockUtilityFabric;
import org.oryxel.viabedrockutility.pack.content.Content;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public final class TextureProcessor {
    private TextureProcessor() {}

    public static void process(final List<Content> packs) {
        final Minecraft client = Minecraft.getInstance();

        for (final Content content : packs) {
            for (final String path : content.getFilesDeep("textures/", "")) {
                final Content.LazyImage image = content.getShortnameImage(path);
                if (image == null) {
                    continue;
                }

                try {
                    final String texturePath = path.toLowerCase(Locale.ROOT)
                            .replaceAll("\\.(png|jpg)$", "");
                    final Identifier identifier = Identifier.fromNamespaceAndPath("minecraft", texturePath);
                    final NativeImage nativeImage = NativeImage.read(image.getPngBytes());
                    client.getTextureManager().register(identifier, new DynamicTexture(identifier.toString(), nativeImage));
                } catch (final IOException exception) {
                    ViaBedrockUtilityFabric.LOGGER.warn("Unable to decode/register texture {}", path, exception);
                } catch (final RuntimeException exception) {
                    ViaBedrockUtilityFabric.LOGGER.warn("Unable to register texture {}", path, exception);
                }
            }
        }
    }
}
