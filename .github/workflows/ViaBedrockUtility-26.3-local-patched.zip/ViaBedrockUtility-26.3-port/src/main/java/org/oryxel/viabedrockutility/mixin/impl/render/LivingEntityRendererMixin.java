package org.oryxel.viabedrockutility.mixin.impl.render;

import net.minecraft.client.model.Model;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.rendertype.RenderType;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @org.spongepowered.asm.mixin.injection.Redirect(
            method = "submit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/model/EntityModel;setupAnim(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;)V"
            ),
            require = 0
    )
    private void viabedrockutility$setupCustomPlayerModel(final net.minecraft.client.model.EntityModel<?> original,
                                                            final EntityRenderState state) {
        if (state instanceof AvatarRenderState avatarState) {
            final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
            if (utility.isViaBedrockPresent() && utility.getPayloadHandler() != null) {
                final PlayerModel custom = utility.getPayloadHandler().getPlayerModel(avatarState.id);
                if (custom != null) {
                    custom.setupAnim(avatarState);
                    return;
                }
            }
        }
        original.setupAnim(state);
    }

    @ModifyArg(
            method = "submit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;III)V"
            ),
            index = 0
    )
    private Model viabedrockutility$replacePlayerModel(final Model original,
                                                        final Object state,
                                                        final PoseStack poseStack,
                                                        final RenderType renderType,
                                                        final int light,
                                                        final int overlay,
                                                        final int outline) {
        if (!(state instanceof AvatarRenderState avatarState)) {
            return original;
        }

        final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
        if (!utility.isViaBedrockPresent() || utility.getPayloadHandler() == null) {
            return original;
        }

        final PlayerModel custom = utility.getPayloadHandler().getPlayerModel(avatarState.id);
        return custom != null ? custom : original;
    }
}
