package org.oryxel.viabedrockutility.renderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Creates the 26.3 EntityRendererProvider.Context without hard-coding the
 * constructor signature.  The 26.3 rendering pipeline grew several resource
 * dependencies; matching values by runtime type keeps this helper resilient
 * to small mapping/name changes while still providing real client resources.
 */
public final class EntityRendererContextFactory {
    private EntityRendererContextFactory() {}

    public static EntityRendererProvider.Context create(final Minecraft client) {
        final EntityRenderDispatcher dispatcher = client.getEntityRenderDispatcher();
        for (final Constructor<?> constructor : EntityRendererProvider.Context.class.getDeclaredConstructors()) {
            final Class<?>[] parameterTypes = constructor.getParameterTypes();
            final Object[] arguments = new Object[parameterTypes.length];
            boolean dispatcherAssigned = false;
            for (int i = 0; i < parameterTypes.length; i++) {
                final Class<?> type = parameterTypes[i];
                final Object value;

                if (!dispatcherAssigned && type.isAssignableFrom(dispatcher.getClass())) {
                    value = dispatcher;
                    dispatcherAssigned = true;
                } else if (type.isPrimitive()) {
                    value = defaultPrimitiveValue(type);
                } else {
                    value = findClientValue(client, dispatcher, type);
                }
                arguments[i] = value;
            }

            if (!dispatcherAssigned) {
                continue;
            }

            try {
                constructor.setAccessible(true);
                return (EntityRendererProvider.Context) constructor.newInstance(arguments);
            } catch (ReflectiveOperationException ignored) {
                // Try the next constructor shape.
            }
        }

        throw new IllegalStateException("Unable to construct Minecraft 26.3 EntityRendererProvider.Context");
    }

    private static Object findClientValue(final Minecraft client, final EntityRenderDispatcher dispatcher, final Class<?> expectedType) {
        final String simpleName = expectedType.getSimpleName();
        final String getter = switch (simpleName) {
            case "BlockModelResolver" -> "getBlockModelResolver";
            case "ItemModelResolver" -> "getItemModelResolver";
            case "MapRenderer" -> "getMapRenderer";
            case "ResourceManager" -> "getResourceManager";
            case "EntityModelSet" -> "getEntityModels";
            case "AtlasManager" -> "getAtlasManager";
            case "PalettedTextureManager" -> "getPalettedTextureManager";
            case "PlayerSkinRenderCache" -> "playerSkinRenderCache";
            default -> null;
        };

        if (getter != null) {
            try {
                final Method method = client.getClass().getMethod(getter);
                final Object value = method.invoke(client);
                if (expectedType.isInstance(value)) {
                    return value;
                }
            } catch (ReflectiveOperationException ignored) {
                // Fall through to field lookup for client-owned values.
            }
        }

        // EquipmentAssetManager is owned by the entity renderer dispatcher in 26.3.
        if ("EquipmentAssetManager".equals(simpleName)) {
            for (final String fieldName : new String[] {"equipmentAssets", "equipmentAssetManager"}) {
                try {
                    final Field field = dispatcher.getClass().getDeclaredField(fieldName);
                    field.setAccessible(true);
                    final Object value = field.get(dispatcher);
                    if (expectedType.isInstance(value)) {
                        return value;
                    }
                } catch (ReflectiveOperationException ignored) {
                    // Try the next candidate field.
                }
            }
        }

        if ("Font".equals(simpleName) || "PlayerSkinRenderCache".equals(simpleName)) {
            final String fieldName = "Font".equals(simpleName) ? "font" : "playerSkinRenderCache";
            try {
                final Field field = client.getClass().getDeclaredField(fieldName);
                field.setAccessible(true);
                final Object value = field.get(client);
                if (expectedType.isInstance(value)) {
                    return value;
                }
            } catch (ReflectiveOperationException ignored) {
                // Leave unresolved; another constructor shape may not need it.
            }
        }

        return null;
    }

    private static Object defaultPrimitiveValue(final Class<?> type) {
        if (type == boolean.class) return false;
        if (type == float.class) return 0.0F;
        if (type == double.class) return 0.0D;
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        if (type == short.class) return (short) 0;
        if (type == byte.class) return (byte) 0;
        if (type == char.class) return '\0';
        return null;
    }
}
