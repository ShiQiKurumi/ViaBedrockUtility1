package org.oryxel.viabedrockutility.renderer.model;

import lombok.Getter;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import org.oryxel.viabedrockutility.renderer.CustomEntityRenderer;

@Getter
public class CustomEntityModel<T extends CustomEntityRenderer.CustomEntityRenderState> extends EntityModel<T> {
    public CustomEntityModel(final ModelPart root) {
        super(root);
    }
}
