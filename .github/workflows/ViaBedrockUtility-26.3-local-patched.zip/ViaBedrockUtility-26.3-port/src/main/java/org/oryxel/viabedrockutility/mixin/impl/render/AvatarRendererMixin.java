package org.oryxel.viabedrockutility.mixin.impl.render;

import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.resources.Identifier;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AvatarRenderer.class)
public abstract class AvatarRendererMixin {
    @Inject(method = "getTextureLocation", at = @At("RETURN"), cancellable = true)
    private void viabedrockutility$getTextureLocation(final AvatarRenderState state,
                                                        final CallbackInfoReturnable<Identifier> cir) {
        final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
        if (!utility.isViaBedrockPresent() || utility.getPayloadHandler() == null) {
            return;
        }

        final Identifier customTexture = utility.getPayloadHandler().getPlayerTexture(state.id);
        if (customTexture != null) {
            cir.setReturnValue(customTexture);
        }
    }
}
