package org.oryxel.viabedrockutility.mixin.impl;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftClientMixin {
    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;Z)V", at = @At("HEAD"))
    private void viabedrockutility$disconnect(final Screen disconnectionScreen, final boolean transferring, final CallbackInfo ci) {
        final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
        utility.setViaBedrockPresent(false);
        if (utility.getPayloadHandler() == null) {
            return;
        }

        utility.getPayloadHandler().getCachedPlayerModels().clear();
        utility.getPayloadHandler().getCachedPlayerModelsByEntityId().clear();
        utility.getPayloadHandler().getCachedPlayerTextures().clear();
        utility.getPayloadHandler().getCachedPlayerTexturesByEntityId().clear();
        utility.getPayloadHandler().getCachedCustomEntities().clear();
        utility.getPayloadHandler().getCachedPlayerCapes().clear();
        utility.getPayloadHandler().getCachedPlayerCapesByEntityId().clear();
        utility.getPayloadHandler().getCachedSkinInfo().clear();
    }
}
