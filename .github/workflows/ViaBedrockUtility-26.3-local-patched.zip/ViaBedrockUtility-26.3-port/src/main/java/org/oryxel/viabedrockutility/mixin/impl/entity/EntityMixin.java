package org.oryxel.viabedrockutility.mixin.impl.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.mixin.interfaces.IEntityDistanceTraveled;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin implements IEntityDistanceTraveled {
    @Unique private float vbu$distanceTraveled;
    @Unique private Vec3 vbu$lastPosition;

    @Inject(method = "setPos", at = @At("HEAD"))
    private void vbu$trackDistance(final double x, final double y, final double z, final CallbackInfo ci) {
        if (!ViaBedrockUtility.getInstance().isViaBedrockPresent()) {
            return;
        }

        final Vec3 next = new Vec3(x, y, z);
        if (this.vbu$lastPosition != null) {
            final double dx = next.x - this.vbu$lastPosition.x;
            final double dz = next.z - this.vbu$lastPosition.z;
            this.vbu$distanceTraveled += (float) Math.sqrt(dx * dx + dz * dz);
        }
        this.vbu$lastPosition = next;
    }

    @Override
    public float viaBedrockUtility$getDistanceTraveled() {
        return this.vbu$distanceTraveled;
    }
}
