package org.oryxel.viabedrockutility.payload.impl.skin;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import org.oryxel.viabedrockutility.payload.BasePayload;

import java.util.UUID;

@RequiredArgsConstructor
@Getter
public final class BaseSkinPayload extends BasePayload {
    public static final StreamCodec<RegistryFriendlyByteBuf, BaseSkinPayload> STREAM_DECODER = StreamCodec.of(
            (buf, payload) -> {
            },
            buf -> {
                final UUID playerUuid = buf.readUUID();
                final int skinWidth = buf.readInt();
                final int skinHeight = buf.readInt();
                final String resourcePatch = BasePayload.readString(buf);

                String geometry = "";
                if (buf.readBoolean()) {
                    geometry = BasePayload.readString(buf);
                }

                return new BaseSkinPayload(playerUuid, skinWidth, skinHeight, geometry, resourcePatch, buf.readInt());
            }
    );

    private final UUID playerUuid;
    private final int skinWidth;
    private final int skinHeight;
    private final String geometry;
    private final String resourcePatch;
    private final int chunkCount;
}
