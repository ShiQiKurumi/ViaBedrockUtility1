package org.oryxel.viabedrockutility.mixin.impl.render.dispatcher;

import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.entity.CustomEntityTicker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@SuppressWarnings("unchecked")
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(
            method = "getRenderer(Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/client/renderer/entity/EntityRenderer;",
            at = @At("HEAD"),
            cancellable = true
    )
    private <T extends Entity> void viabedrockutility$getRenderer(final T entity,
                                                                    final CallbackInfoReturnable<EntityRenderer<? super T, ?>> cir) {
        final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
        if (!utility.isViaBedrockPresent() || utility.getPayloadHandler() == null) {
            return;
        }

        final CustomEntityTicker ticker = utility.getPayloadHandler().getCachedCustomEntities().get(entity.getUuid());
        if (ticker != null && ticker.getRenderer() != null) {
            cir.setReturnValue((EntityRenderer<? super T, ?>) ticker.getRenderer());
        }
    }
}
