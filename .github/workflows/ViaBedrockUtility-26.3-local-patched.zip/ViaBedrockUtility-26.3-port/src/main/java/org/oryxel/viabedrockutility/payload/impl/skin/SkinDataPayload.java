package org.oryxel.viabedrockutility.payload.impl.skin;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import org.oryxel.viabedrockutility.payload.BasePayload;

import java.util.UUID;

@RequiredArgsConstructor
@Getter
public final class SkinDataPayload extends BasePayload {
    public static final StreamCodec<RegistryFriendlyByteBuf, SkinDataPayload> STREAM_DECODER = StreamCodec.of(
            (buf, payload) -> {
            },
            buf -> {
                final UUID playerUuid = buf.readUUID();
                final int chunkPosition = buf.readInt();
                final int available = buf.readableBytes();
                final byte[] skinData = new byte[available];
                buf.readBytes(skinData);
                return new SkinDataPayload(playerUuid, chunkPosition, available, skinData);
            }
    );

    private final UUID playerUuid;
    private final int chunkPosition;
    private final int available;
    private final byte[] skinData;
}
