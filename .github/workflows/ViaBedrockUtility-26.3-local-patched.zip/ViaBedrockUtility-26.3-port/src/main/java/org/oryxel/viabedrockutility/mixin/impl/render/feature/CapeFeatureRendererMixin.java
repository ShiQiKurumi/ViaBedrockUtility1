package org.oryxel.viabedrockutility.mixin.impl.render.feature;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.layers.CapeLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.fabric.ViaBedrockUtilityFabric;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CapeLayer.class)
public abstract class CapeFeatureRendererMixin {
    @Unique
    private static final ThreadLocal<AvatarRenderState> VBU_CURRENT_STATE = new ThreadLocal<>();

    @Inject(method = "submit", at = @At("HEAD"))
    private void viabedrockutility$captureState(final PoseStack poseStack,
                                                  final SubmitNodeCollector collector,
                                                  final int light,
                                                  final AvatarRenderState state,
                                                  final float yRot,
                                                  final float xRot,
                                                  final CallbackInfo ci) {
        VBU_CURRENT_STATE.set(state);
    }

    @Inject(method = "submit", at = @At("RETURN"))
    private void viabedrockutility$clearState(final PoseStack poseStack,
                                                final SubmitNodeCollector collector,
                                                final int light,
                                                final AvatarRenderState state,
                                                final float yRot,
                                                final float xRot,
                                                final CallbackInfo ci) {
        VBU_CURRENT_STATE.remove();
    }

    @ModifyArg(
            method = "submit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/rendertype/RenderTypes;entitySolid(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/client/renderer/rendertype/RenderType;"
            ),
            index = 0,
            require = 0
    )
    private Identifier viabedrockutility$replaceCape(final Identifier original) {
        final AvatarRenderState state = VBU_CURRENT_STATE.get();
        if (state == null) {
            return original;
        }

        final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
        if (!utility.isViaBedrockPresent() || utility.getPayloadHandler() == null) {
            return original;
        }

        final Identifier customCape = utility.getPayloadHandler().getPlayerCape(state.id);
        return customCape == null ? original : customCape;
    }
}
