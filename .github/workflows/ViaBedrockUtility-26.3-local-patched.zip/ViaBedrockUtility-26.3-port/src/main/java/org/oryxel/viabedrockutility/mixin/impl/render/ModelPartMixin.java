package org.oryxel.viabedrockutility.mixin.impl.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelPart;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.oryxel.viabedrockutility.mixin.interfaces.IModelPart;
import org.oryxel.viabedrockutility.util.MathUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Map;

@Mixin(ModelPart.class)
public abstract class ModelPartMixin implements IModelPart {
    @Shadow public float x;
    @Shadow public float z;
    @Shadow @Final private Map<String, ModelPart> children;
    @Shadow public abstract List<ModelPart> getAllParts();
    @Shadow public float xScale;
    @Shadow public float yScale;
    @Shadow public float zScale;

    @Unique private String name = "";
    @Unique private boolean isVBUModel;
    @Unique private boolean neededOffset;
    @Unique private Vector3f pivot = new Vector3f();
    @Unique private Vector3f offset = new Vector3f();
    @Unique private Vector3f rotation = new Vector3f();
    @Unique private Vector3f defaultRotation = new Vector3f();
    @Unique private boolean alreadySetRotation;

    @Inject(method = "translateAndRotate", at = @At("HEAD"))
    private void vbu$translateAndRotate(final PoseStack poseStack, final CallbackInfo ci) {
        poseStack.translate(this.offset.x / 16.0F, this.offset.y / 16.0F, this.offset.z / 16.0F);
        poseStack.translate(this.pivot.x / 16.0F, this.pivot.y / 16.0F, this.pivot.z / 16.0F);
        poseStack.mulPose(new Quaternionf().rotationXYZ(
                this.rotation.x * MathUtil.DEGREES_TO_RADIANS,
                this.rotation.y * MathUtil.DEGREES_TO_RADIANS,
                this.rotation.z * MathUtil.DEGREES_TO_RADIANS
        ));
        poseStack.translate(-this.pivot.x / 16.0F, -this.pivot.y / 16.0F, -this.pivot.z / 16.0F);
        poseStack.translate(-this.offset.x / 16.0F, -this.offset.y / 16.0F, -this.offset.z / 16.0F);
    }

    @Inject(method = "translateAndRotate", at = @At("TAIL"))
    private void vbu$translateAndRotateTail(final PoseStack poseStack, final CallbackInfo ci) {
        poseStack.translate(this.offset.x / 16.0F, this.offset.y / 16.0F, this.offset.z / 16.0F);
        if (this.isVBUModel && this.neededOffset) {
            poseStack.translate(-this.x / 16.0F, 0.0F, -this.z / 16.0F);
        }
    }

    @Inject(method = "getChild", at = @At("HEAD"), cancellable = true)
    private void vbu$getChild(final String childName, final CallbackInfoReturnable<ModelPart> cir) {
        if (this.isVBUModel) {
            cir.setReturnValue(this.children.getOrDefault(childName, new ModelPart(List.of(), Map.of())));
        }
    }

    @Override
    public String viaBedrockUtility$getName() { return this.name; }

    @Override
    public void viaBedrockUtility$setName(final String name) { this.name = name; }

    @Override
    public void viaBedrockUtility$setNeededOffset(final boolean needed) { this.neededOffset = needed; }

    @Override
    public boolean viaBedrockUtility$isVBUModel() { return this.isVBUModel; }

    @Override
    public void viaBedrockUtility$setVBUModel() { this.isVBUModel = true; }

    @Override
    public void viaBedrockUtility$resetEverything() {
        this.getAllParts().forEach(part -> ((IModelPart) (Object) part).viaBedrockUtility$restoreDefaults());
    }

    @Override
    public void viaBedrockUtility$restoreDefaults() {
        this.offset.set(0.0F, 0.0F, 0.0F);
        this.rotation.set(this.defaultRotation);
        this.xScale = this.yScale = this.zScale = 1.0F;
    }

    @Override
    public void viaBedrockUtility$setPivot(final Vector3f vec3) { this.pivot = vec3; }

    @Override
    public void viaBedrockUtility$setOffset(final Vector3f vec3) { this.offset = new Vector3f(vec3.x, -vec3.y, vec3.z); }

    @Override
    public void viaBedrockUtility$setAngles(final Vector3f vec3) {
        if (!this.alreadySetRotation) {
            this.defaultRotation = new Vector3f(vec3);
            this.alreadySetRotation = true;
        }
        this.rotation = new Vector3f(vec3);
    }
}
