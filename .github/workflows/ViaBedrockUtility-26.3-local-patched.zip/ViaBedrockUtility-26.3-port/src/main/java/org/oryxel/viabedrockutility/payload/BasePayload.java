package org.oryxel.viabedrockutility.payload;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.enums.bedrock.ActorFlags;
import org.oryxel.viabedrockutility.fabric.ViaBedrockUtilityFabric;
import org.oryxel.viabedrockutility.payload.enums.PayloadType;
import org.oryxel.viabedrockutility.payload.impl.entity.ModelRequestPayload;
import org.oryxel.viabedrockutility.payload.impl.skin.BaseSkinPayload;
import org.oryxel.viabedrockutility.payload.impl.skin.CapeDataPayload;
import org.oryxel.viabedrockutility.payload.impl.skin.SkinDataPayload;
import org.oryxel.viabedrockutility.util.EnumUtil;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

@RequiredArgsConstructor
@Getter
public class BasePayload implements CustomPacketPayload {
    public static final Type<BasePayload> ID = new Type<>(Identifier.fromNamespaceAndPath(ViaBedrockUtilityFabric.MOD_ID, "data"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BasePayload> STREAM_CODEC = StreamCodec.of(
            (buf, payload) -> {
                // S2C-only payload. The encoder intentionally emits nothing.
            },
            buf -> {
                final int type = buf.readInt();
                if (type < 0 || type >= PayloadType.values().length) {
                    throw new IllegalArgumentException("Invalid ViaBedrockUtility payload type: " + type);
                }

                return switch (PayloadType.values()[type]) {
                    case CONFIRM -> {
                        ViaBedrockUtility.getInstance().setViaBedrockPresent(true);
                        yield new BasePayload();
                    }
                    case MODEL_REQUEST -> {
                        final String identifier = readString(buf);

                        BigInteger combinedFlags = BigInteger.ZERO;
                        if (buf.readBoolean()) {
                            combinedFlags = combinedFlags.add(unsignedLongToBigInteger(buf.readLong()));
                        }
                        if (buf.readBoolean()) {
                            combinedFlags = combinedFlags.add(unsignedLongToBigInteger(buf.readLong()).shiftLeft(64));
                        }

                        Integer variant = null;
                        Integer markVariant = null;
                        if (buf.readBoolean()) {
                            variant = buf.readInt();
                        }
                        if (buf.readBoolean()) {
                            markVariant = buf.readInt();
                        }

                        yield new ModelRequestPayload(
                                identifier,
                                EnumUtil.getEnumSetFromBitmask(ActorFlags.class, combinedFlags, ActorFlags::getValue),
                                variant,
                                markVariant,
                                buf.readUUID()
                        );
                    }
                    case ANIMATE -> new BasePayload();
                    case CAPE -> CapeDataPayload.STREAM_DECODER.decode(buf);
                    case SKIN_INFORMATION -> BaseSkinPayload.STREAM_DECODER.decode(buf);
                    case SKIN_DATA -> SkinDataPayload.STREAM_DECODER.decode(buf);
                };
            }
    );

    public void handle(final PayloadHandler handler) {
        try {
            handler.handle(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return ID;
    }

    private static BigInteger unsignedLongToBigInteger(final long value) {
        BigInteger result = BigInteger.valueOf(value & Long.MAX_VALUE);
        if (value < 0) {
            result = result.setBit(63);
        }
        return result;
    }

    public static String readString(final RegistryFriendlyByteBuf buf) {
        final int length = buf.readInt();
        if (length < 0 || length > buf.readableBytes()) {
            throw new IllegalArgumentException("Invalid ViaBedrockUtility string length: " + length);
        }

        final String result = buf.toString(buf.readerIndex(), length, StandardCharsets.UTF_8);
        buf.readerIndex(buf.readerIndex() + length);
        return result;
    }
}
