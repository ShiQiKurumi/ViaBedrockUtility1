package org.oryxel.viabedrockutility.mixin.impl.pack;

import net.minecraft.client.resources.server.ServerResourcePackLoader;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.fabric.ViaBedrockUtilityFabric;
import org.oryxel.viabedrockutility.pack.PackManager;
import org.oryxel.viabedrockutility.pack.content.Content;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

@Mixin(ServerResourcePackLoader.class)
public abstract class ServerResourcePackLoaderMixin {
    /**
     * The resource-pack loader's PackInfo record has changed between minor 26.x mappings.
     * Its JVM signature is still List, so keep this mixin independent of that nested type.
     */
    @Inject(method = "toProfiles", at = @At("HEAD"), require = 0)
    private void viabedrockutility$toProfiles(final List<?> packs, final CallbackInfoReturnable<?> cir) {
        if (!ViaBedrockUtility.getInstance().isViaBedrockPresent()) {
            return;
        }

        final List<Content> contents = new ArrayList<>();
        for (final Object packInfo : packs) {
            final Path path = getPackPath(packInfo);
            if (path == null) {
                continue;
            }

            try {
                final Content content = new Content(Files.readAllBytes(path));
                for (final String mcpackPath : content.getFilesDeep("bedrock/", ".mcpack")) {
                    final byte[] mcpack = content.get(mcpackPath);
                    if (mcpack != null) {
                        contents.add(new Content(mcpack));
                    }
                }
            } catch (IOException exception) {
                ViaBedrockUtilityFabric.LOGGER.warn("Failed to read server resource pack {}", path, exception);
            }
        }

        if (!contents.isEmpty()) {
            ViaBedrockUtility.getInstance().setPackManager(new PackManager(contents));
        }
    }

    private static Path getPackPath(final Object packInfo) {
        if (packInfo == null) {
            return null;
        }

        try {
            final Method pathMethod = packInfo.getClass().getMethod("path");
            final Object value = pathMethod.invoke(packInfo);
            return value instanceof Path path ? path : null;
        } catch (ReflectiveOperationException ignored) {
            try {
                final var field = packInfo.getClass().getDeclaredField("path");
                field.setAccessible(true);
                final Object value = field.get(packInfo);
                return value instanceof Path path ? path : null;
            } catch (ReflectiveOperationException ignoredAgain) {
                return null;
            }
        }
    }
}
