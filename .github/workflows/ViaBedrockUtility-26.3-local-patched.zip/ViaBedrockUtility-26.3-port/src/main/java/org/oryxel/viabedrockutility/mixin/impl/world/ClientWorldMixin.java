package org.oryxel.viabedrockutility.mixin.impl.world;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.payload.PayloadHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLevel.class)
public abstract class ClientWorldMixin {
    @Inject(method = "removeEntity", at = @At("HEAD"))
    private void viabedrockutility$removeEntity(final int entityId,
                                                 final Entity.RemovalReason removalReason,
                                                 final CallbackInfo ci) {
        final ViaBedrockUtility utility = ViaBedrockUtility.getInstance();
        if (!utility.isViaBedrockPresent() || utility.getPayloadHandler() == null) {
            return;
        }

        final PayloadHandler handler = utility.getPayloadHandler();
        final Entity entity = ((ClientLevel) (Object) this).getEntity(entityId);
        if (entity == null) {
            return;
        }

        final int id = entity.getId();
        handler.getCachedPlayerModels().remove(entity.getUuid());
        handler.getCachedPlayerModelsByEntityId().remove(id);
        handler.getCachedPlayerTextures().remove(entity.getUuid());
        handler.getCachedPlayerTexturesByEntityId().remove(id);
        handler.getCachedCustomEntities().remove(entity.getUuid());
        handler.getCachedPlayerCapes().remove(entity.getUuid());
        handler.getCachedPlayerCapesByEntityId().remove(id);
        handler.getCachedSkinInfo().remove(entity.getUuid());
    }
}
