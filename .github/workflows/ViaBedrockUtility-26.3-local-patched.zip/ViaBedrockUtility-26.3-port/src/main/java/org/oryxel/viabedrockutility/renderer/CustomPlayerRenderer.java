package org.oryxel.viabedrockutility.renderer;

/**
 * Player rendering is now handled by the vanilla AvatarRenderer through mixins.
 * This class remains only as a compatibility marker for source consumers of the old project.
 */
public final class CustomPlayerRenderer {
    private CustomPlayerRenderer() {}
}
