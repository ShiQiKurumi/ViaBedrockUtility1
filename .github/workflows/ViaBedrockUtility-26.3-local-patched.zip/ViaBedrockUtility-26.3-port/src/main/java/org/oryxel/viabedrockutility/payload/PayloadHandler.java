package org.oryxel.viabedrockutility.payload;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.Identifier;
import org.cube.converter.model.impl.bedrock.BedrockGeometryModel;
import org.oryxel.viabedrockutility.ViaBedrockUtility;
import org.oryxel.viabedrockutility.entity.CustomEntityTicker;
import org.oryxel.viabedrockutility.fabric.ViaBedrockUtilityFabric;
import org.oryxel.viabedrockutility.pack.PackManager;
import org.oryxel.viabedrockutility.payload.impl.entity.ModelRequestPayload;
import org.oryxel.viabedrockutility.payload.impl.skin.BaseSkinPayload;
import org.oryxel.viabedrockutility.payload.impl.skin.CapeDataPayload;
import org.oryxel.viabedrockutility.payload.impl.skin.SkinDataPayload;
import org.oryxel.viabedrockutility.util.GeometryUtil;
import org.oryxel.viabedrockutility.util.ImageUtil;

import com.mojang.blaze3d.platform.NativeImage;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Getter
public class PayloadHandler {
    protected final Map<UUID, CustomEntityTicker> cachedCustomEntities = new ConcurrentHashMap<>();

    /** Custom Bedrock player models, indexed by both player UUID and client entity id. */
    protected final Map<UUID, PlayerModel> cachedPlayerModels = new ConcurrentHashMap<>();
    protected final Map<Integer, PlayerModel> cachedPlayerModelsByEntityId = new ConcurrentHashMap<>();

    /** Custom skin/cape texture identifiers, indexed by both UUID and entity id. */
    protected final Map<UUID, Identifier> cachedPlayerTextures = new ConcurrentHashMap<>();
    protected final Map<Integer, Identifier> cachedPlayerTexturesByEntityId = new ConcurrentHashMap<>();
    protected final Map<UUID, Identifier> cachedPlayerCapes = new ConcurrentHashMap<>();
    protected final Map<Integer, Identifier> cachedPlayerCapesByEntityId = new ConcurrentHashMap<>();

    protected final Map<UUID, SkinInfo> cachedSkinInfo = new ConcurrentHashMap<>();
    protected PackManager packManager;

    public void handle(final BasePayload payload) {
        if (this.packManager != ViaBedrockUtility.getInstance().getPackManager()) {
            this.packManager = ViaBedrockUtility.getInstance().getPackManager();
        }

        if (payload instanceof ModelRequestPayload modelRequest) {
            if (this.packManager != null) {
                this.handle(modelRequest);
            }
        } else if (payload instanceof BaseSkinPayload baseSkin) {
            this.cachedSkinInfo.put(baseSkin.getPlayerUuid(), new SkinInfo(
                    baseSkin.getGeometry(),
                    baseSkin.getResourcePatch(),
                    baseSkin.getSkinWidth(),
                    baseSkin.getSkinHeight(),
                    baseSkin.getChunkCount()
            ));
        } else if (payload instanceof SkinDataPayload skinData) {
            this.handle(skinData);
        } else if (payload instanceof CapeDataPayload capePayload) {
            this.handle(capePayload);
        }
    }

    public void handle(final ModelRequestPayload payload) {
        // Implemented by CustomEntityPayloadHandler.
    }

    public void handle(final CapeDataPayload payload) {
        final NativeImage capeImage = ImageUtil.toNativeImage(payload.getCapeData(), payload.getWidth(), payload.getHeight());
        if (capeImage == null) {
            return;
        }

        final Minecraft client = Minecraft.getInstance();
        registerTexture(client.getTextureManager(), payload.getIdentifier(), capeImage);

        this.cachedPlayerCapes.put(payload.getPlayerUuid(), payload.getIdentifier());
        bindEntityId(client, payload.getPlayerUuid(), (entityId, uuid) -> {
            this.cachedPlayerCapesByEntityId.put(entityId, this.cachedPlayerCapes.get(uuid));
        });
    }

    private static final List<String> HARDCODED_GEOMETRY_IDENTIFIERS = List.of(
            "geometry.humanoid.custom", "geometry.humanoid.customSlim");

    public void handle(final SkinDataPayload payload) {
        final SkinInfo info = this.cachedSkinInfo.get(payload.getPlayerUuid());
        if (info == null) {
            ViaBedrockUtilityFabric.LOGGER.error("Skin info was null for {}", payload.getPlayerUuid());
            return;
        }

        try {
            info.setData(payload.getSkinData(), payload.getChunkPosition());
        } catch (Exception exception) {
            ViaBedrockUtilityFabric.LOGGER.error("Failed to store skin chunk {} for {}", payload.getChunkPosition(), payload.getPlayerUuid(), exception);
            return;
        }

        if (!info.isComplete()) {
            return;
        }
        this.cachedSkinInfo.remove(payload.getPlayerUuid());

        final NativeImage skinImage = ImageUtil.toNativeImage(info.getData(), info.getWidth(), info.getHeight());
        if (skinImage == null) {
            return;
        }

        final Minecraft client = Minecraft.getInstance();
        final Identifier identifier = Identifier.fromNamespaceAndPath(
                ViaBedrockUtilityFabric.MOD_ID,
                "player/" + payload.getPlayerUuid()
        );
        registerTexture(client.getTextureManager(), identifier, skinImage);
        this.cachedPlayerTextures.put(payload.getPlayerUuid(), identifier);

        // In 26.3 PlayerSkin is immutable and its textures are ClientAsset records.
        // We therefore no longer mutate PlayerInfo; the renderer mixin resolves our
        // texture from this cache directly.
        bindEntityId(client, payload.getPlayerUuid(), (entityId, uuid) -> {
            this.cachedPlayerTexturesByEntityId.put(entityId, this.cachedPlayerTextures.get(uuid));
        });

        String requiredGeometry = null;
        try {
            final JsonObject patch = JsonParser.parseString(info.getResourcePatch()).getAsJsonObject();
            final JsonObject geometry = patch.getAsJsonObject("geometry");
            if (geometry != null && geometry.has("default")) {
                requiredGeometry = geometry.get("default").getAsString();
            }
        } catch (Exception ignored) {
        }

        final boolean slim = requiredGeometry != null && requiredGeometry.contains("customSlim");
        PlayerModel model = null;

        if (!info.getGeometryRaw().isEmpty()) {
            try {
                final JsonObject object = JsonParser.parseString(info.getGeometryRaw()).getAsJsonObject();
                final List<BedrockGeometryModel> geometries = BedrockGeometryModel.fromJson(object);
                if (!geometries.isEmpty()) {
                    BedrockGeometryModel selected = geometries.getFirst();
                    if (requiredGeometry != null) {
                        for (final BedrockGeometryModel geometry : geometries) {
                            if (requiredGeometry.equals(geometry.getIdentifier())) {
                                selected = geometry;
                                break;
                            }
                        }
                    }
                    model = GeometryUtil.buildPlayerModel(selected, slim);
                }
            } catch (Exception exception) {
                ViaBedrockUtilityFabric.LOGGER.warn("Failed to build Bedrock player geometry for {}", payload.getPlayerUuid(), exception);
            }
        }

        // Classic/known geometry identifiers use the vanilla player mesh. The texture
        // replacement still works even when there is no custom geometry payload.
        if (model == null && requiredGeometry != null) {
            boolean known = HARDCODED_GEOMETRY_IDENTIFIERS.stream().anyMatch(requiredGeometry::equals);
            if (known) {
                ViaBedrockUtilityFabric.LOGGER.debug("Using vanilla player model for known geometry {}", requiredGeometry);
            }
        }

        if (model != null) {
            this.cachedPlayerModels.put(payload.getPlayerUuid(), model);
            bindEntityId(client, payload.getPlayerUuid(), (entityId, uuid) -> {
                final PlayerModel cached = this.cachedPlayerModels.get(uuid);
                if (cached != null) {
                    this.cachedPlayerModelsByEntityId.put(entityId, cached);
                }
            });
        }
    }

    public PlayerModel getPlayerModel(final int entityId) {
        PlayerModel model = this.cachedPlayerModelsByEntityId.get(entityId);
        if (model != null) {
            return model;
        }
        final Minecraft client = Minecraft.getInstance();
        if (client.level == null) {
            return null;
        }
        final var entity = client.level.getEntity(entityId);
        if (entity == null) {
            return null;
        }
        model = this.cachedPlayerModels.get(entity.getUUID());
        if (model != null) {
            this.cachedPlayerModelsByEntityId.put(entityId, model);
        }
        return model;
    }

    public Identifier getPlayerCape(final int entityId) {
        Identifier cape = this.cachedPlayerCapesByEntityId.get(entityId);
        if (cape != null) {
            return cape;
        }
        final Minecraft client = Minecraft.getInstance();
        if (client.level == null) {
            return null;
        }
        final var entity = client.level.getEntity(entityId);
        if (entity == null) {
            return null;
        }
        cape = this.cachedPlayerCapes.get(entity.getUUID());
        if (cape != null) {
            this.cachedPlayerCapesByEntityId.put(entityId, cape);
        }
        return cape;
    }

    public Identifier getPlayerTexture(final int entityId) {
        Identifier texture = this.cachedPlayerTexturesByEntityId.get(entityId);
        if (texture != null) {
            return texture;
        }
        final Minecraft client = Minecraft.getInstance();
        if (client.level == null) {
            return null;
        }
        final var entity = client.level.getEntity(entityId);
        if (entity == null) {
            return null;
        }
        texture = this.cachedPlayerTextures.get(entity.getUUID());
        if (texture != null) {
            this.cachedPlayerTexturesByEntityId.put(entityId, texture);
        }
        return texture;
    }

    private static void registerTexture(final TextureManager textureManager, final Identifier identifier, final NativeImage image) {
        try {
            textureManager.register(identifier, new DynamicTexture(identifier.toString(), image));
        } catch (Exception exception) {
            ViaBedrockUtilityFabric.LOGGER.error("Failed to register texture {}", identifier, exception);
            try {
                image.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static void bindEntityId(final Minecraft client, final UUID uuid, final EntityIdConsumer consumer) {
        if (client.level == null) {
            return;
        }

        final var player = client.level.getPlayerByUUID(uuid);
        if (player != null) {
            consumer.accept(player.getId(), uuid);
        }
    }

    @FunctionalInterface
    private interface EntityIdConsumer {
        void accept(int entityId, UUID uuid);
    }

    @Getter
    public static class SkinInfo {
        private final String geometryRaw, resourcePatch;
        private final int width, height;
        private final byte[][] skinData;

        public SkinInfo(final String geometryRaw, final String resourcePatch, final int width, final int height, final int chunkCount) {
            this.geometryRaw = geometryRaw == null ? "" : geometryRaw;
            this.resourcePatch = resourcePatch == null ? "{}" : resourcePatch;
            this.skinData = new byte[Math.max(0, chunkCount)][];
            this.width = width;
            this.height = height;
        }

        /** Assemble the chunks in their original order, matching ViaBedrock's payload format. */
        public byte[] getData() {
            int totalLength = 0;
            for (byte[] data : this.skinData) {
                if (data != null) {
                    totalLength += data.length;
                }
            }

            final byte[] totalData = new byte[totalLength];
            int currentIndex = 0;
            for (byte[] currentData : this.skinData) {
                if (currentData == null) {
                    continue;
                }
                System.arraycopy(currentData, 0, totalData, currentIndex, currentData.length);
                currentIndex += currentData.length;
            }
            return totalData;
        }

        public void setData(final byte[] data, final int chunk) {
            if (data == null || chunk < 0 || chunk >= this.skinData.length) {
                return;
            }
            this.skinData[chunk] = data;
        }

        public boolean isComplete() {
            if (this.skinData.length == 0) {
                return false;
            }
            for (byte[] data : this.skinData) {
                if (data == null) {
                    return false;
                }
            }
            return true;
        }
    }
}
