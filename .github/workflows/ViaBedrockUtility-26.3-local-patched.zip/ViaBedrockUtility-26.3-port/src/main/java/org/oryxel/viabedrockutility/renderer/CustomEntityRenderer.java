package org.oryxel.viabedrockutility.renderer;

import lombok.Getter;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import org.oryxel.viabedrockutility.animation.animator.Animator;
import org.oryxel.viabedrockutility.entity.CustomEntityTicker;
import org.oryxel.viabedrockutility.material.data.Material;
import org.oryxel.viabedrockutility.pack.definitions.AnimationDefinitions;
import org.oryxel.viabedrockutility.renderer.model.CustomEntityModel;
import org.oryxel.viabedrockutility.mixin.interfaces.IEntityDistanceTraveled;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Getter
public class CustomEntityRenderer<T extends Entity> extends EntityRenderer<T, CustomEntityRenderer.CustomEntityRenderState> {
    private final Map<String, Animator> animators = new ConcurrentHashMap<>();
    private final CustomEntityTicker ticker;
    private final List<Model> models;

    public CustomEntityRenderer(final CustomEntityTicker ticker, final List<Model> models, final EntityRendererProvider.Context context) {
        super(context);
        this.models = models;
        this.ticker = ticker;
    }

    @Override
    public void submit(final CustomEntityRenderState state, final PoseStack poseStack, final SubmitNodeCollector submitNodeCollector, final CameraRenderState camera) {
        for (final Model model : this.models) {
            poseStack.pushPose();
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - state.yaw));
            poseStack.scale(-1.0F, -1.0F, 1.0F);
            poseStack.translate(0.0F, -1.501F, 0.0F);

            this.animators.values().forEach(animator -> {
                try {
                    animator.animate(model.model(), state);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });

            final RenderType renderType = model.material().info().getVariants().getOrDefault("skinning_color", model.material().info()).build().apply(model.texture());
            if (renderType != null) {
                submitNodeCollector.submitModel(model.model(), state, poseStack, renderType, state.lightCoords, OverlayTexture.NO_OVERLAY, -1);
            }
            poseStack.popPose();
        }
    }

    @Override
    public boolean shouldRender(final T entity, final Frustum frustum, final double x, final double y, final double z, final float partialTicks) {
        final double d = 64.0F;
        return entity.distanceToSqr(x, y, z) <= d * d;
    }

    @Override
    public void extractRenderState(final T entity, final CustomEntityRenderState state, final float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.yaw = entity.getYRot(partialTick);
        state.bodyYaw = entity.yBodyRot;
        state.bodyPitch = entity.getXRot(partialTick);
        state.distanceTraveled = entity instanceof IEntityDistanceTraveled distance
                ? distance.viaBedrockUtility$getDistanceTraveled()
                : 0.0F;
        state.lightCoords = this.getPackedLightCoords(entity, partialTick);
    }

    @Override
    public CustomEntityRenderState createRenderState() {
        return new CustomEntityRenderState();
    }

    public record Model(String key, String geometry, CustomEntityModel<CustomEntityRenderState> model, Identifier texture, Material material) {
    }

    @Getter
    public static class CustomEntityRenderState extends EntityRenderState {
        private float yaw;
        private float bodyYaw;
        private float bodyPitch;
        private float distanceTraveled;
        private int lightCoords;
    }

    public void reset() {
        this.animators.values().forEach(animator -> this.models.forEach(m -> animator.stop(m.model(), true)));
        this.animators.clear();
    }

    public void play(final AnimationDefinitions.AnimationData data) {
        if (data == null) {
            return;
        }
        this.animators.put(data.animation().getIdentifier(), new Animator(this.ticker, data));
    }
}
