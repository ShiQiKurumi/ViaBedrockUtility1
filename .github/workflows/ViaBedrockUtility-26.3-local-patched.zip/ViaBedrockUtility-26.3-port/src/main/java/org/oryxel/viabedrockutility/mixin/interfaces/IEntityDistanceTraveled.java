package org.oryxel.viabedrockutility.mixin.interfaces;

public interface IEntityDistanceTraveled {
    float viaBedrockUtility$getDistanceTraveled();
}
