package org.oryxel.viabedrockutility.payload.impl.skin;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import org.oryxel.viabedrockutility.fabric.ViaBedrockUtilityFabric;
import org.oryxel.viabedrockutility.payload.BasePayload;

import java.util.UUID;

@RequiredArgsConstructor
@Getter
public final class CapeDataPayload extends BasePayload {
    public static final StreamCodec<RegistryFriendlyByteBuf, CapeDataPayload> STREAM_DECODER = StreamCodec.of(
            (buf, payload) -> {
            },
            buf -> {
                final UUID playerUuid = buf.readUUID();
                final int width = buf.readInt();
                final int height = buf.readInt();
                final String capeId = BasePayload.readString(buf);
                final Identifier identifier = Identifier.fromNamespaceAndPath(ViaBedrockUtilityFabric.MOD_ID, capeId);

                final int dataLength = buf.readInt();
                if (dataLength < 0 || dataLength > buf.readableBytes()) {
                    throw new IllegalArgumentException("Invalid cape payload length: " + dataLength);
                }
                final byte[] capeData = new byte[dataLength];
                buf.readBytes(capeData);
                return new CapeDataPayload(playerUuid, width, height, identifier, capeData);
            }
    );

    private final UUID playerUuid;
    private final int width;
    private final int height;
    private final Identifier identifier;
    private final byte[] capeData;
}
