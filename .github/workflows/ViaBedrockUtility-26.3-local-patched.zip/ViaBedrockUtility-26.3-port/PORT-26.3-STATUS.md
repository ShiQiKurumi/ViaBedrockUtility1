# ViaBedrockUtility — Minecraft 26.3 Port

Target: Minecraft 26.3 / Fabric Loader 0.19.5 / Java 25

## What was ported

- Migrated the Gradle/Loom configuration to the 26.3 development line.
- Switched mappings from 1.21.5 Yarn to official Mojang mappings.
- Migrated custom payload codecs to the modern `StreamCodec` / `RegistryFriendlyByteBuf` API.
- Reconstructed the missing `ActorFlags` enum from the repository's `entity_flag_molang_query_mappings.json` order (this is an inference from the supplied source tree, not a verified upstream enum copy).
- Reworked player skin/cape handling so it no longer mutates the immutable 26.3 `PlayerSkin` record.
- Added player texture/model lookup by both UUID and runtime entity id.
- Migrated custom entity rendering to the 26.3 `EntityRenderer` extract/submit render-state pipeline.
- Reworked model-part animation hooks for the new `ModelPart` API.
- Added `AvatarRenderer` and `LivingEntityRenderer` hooks for custom player texture/model substitution.
- Kept server resource-pack discovery, while avoiding a hard dependency on the 26.3 internal `PackInfo` type by using reflection.
- Added cache cleanup when disconnecting and when client entities are removed.

## Known limitations

1. The original Bedrock material/shader pipeline was built around the old 1.21.5 rendering API. The 26.3 port currently uses vanilla translucent entity `RenderType` as a compatibility fallback, so exact Bedrock shader/blend/depth behaviour is not fully ported yet.
2. Custom cape texture replacement is implemented, but the vanilla cape layer can still gate rendering on the presence of `PlayerSkin.cape()`. This may require a later hook if Bedrock capes are still invisible at runtime.
3. The old debug `$animate` chat/network mixin was removed because its 1.21.5 packet/client-network target no longer exists in the 26.3 client path.
4. The supplied source archive did not contain the original `ActorFlags` class; the enum in this port is reconstructed from the supplied JSON mapping order.

## Build

Use a real Java 25 JDK and an environment with network access to Maven/Gradle dependencies.

```bash
./gradlew clean build
```

Expected output JAR:

```text
build/libs/viabedrockutility-1.0.0-26.3.jar
```

## Validation performed in the supplied container

- `fabric.mod.json` parses as valid JSON.
- The source tree has been scanned for the old 1.21.5 renderer/network class names used by the original implementation.
- The container has only Java 21 installed, no Java 25 JDK, no Minecraft/Fabric 26.3 dependency cache, and no reachable Gradle distribution/Maven network endpoint; therefore a genuine 26.3 Gradle compile could not be completed here.
